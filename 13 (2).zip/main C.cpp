
#include <GL/gl.h>

#include<stdio.h>

#include<math.h>

#include <GL/glut.h>

#include<string.h>

#include<windows.h>



void buil1()

{



    glColor3ub(136, 78, 160 );

    glBegin(GL_POLYGON);

    glVertex2f(95, 180);

    glVertex2f(95, 400);

    glVertex2f(150, 400);

    glVertex2f(150, 180);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(95, 180);

    glVertex2f(95, 400);

    glVertex2f(150, 400);

    glVertex2f(150, 180);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(95, 180);

    glVertex2f(150, 180);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

     glVertex2f(95, 400);

    glVertex2f(150, 400);

    glEnd();



    glColor3ub(187, 143, 206);
    glBegin(GL_POLYGON);

    glVertex2f(110, 180);

    glVertex2f(135, 180);

    glVertex2f(135, 230);

    glVertex2f(110,230);

    glVertex2f(110, 180);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(110, 180);

    glVertex2f(135, 180);

    glVertex2f(135, 230);

    glVertex2f(110,230);

    glVertex2f(110, 180);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(110, 180);

    glVertex2f(110,230);

    glEnd();



     glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(135, 180);

    glVertex2f(135, 230);

    glEnd();





    glColor3ub(232, 218, 239);

    glBegin(GL_POLYGON);

    glVertex2f(100, 250);

    glVertex2f(100,270);

    glVertex2f(115,270);

    glVertex2f(115.1292205993167, 249.8355428409805);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100, 250);

    glVertex2f(100,270);

    glVertex2f(115,270);

    glVertex2f(115.1292205993167, 249.8355428409805);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100, 250);

    glVertex2f(115.1292205993167, 249.8355428409805);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100,270);

    glVertex2f(115,270);

    glEnd();



     glColor3ub(232, 218, 239);

    glBegin(GL_POLYGON);

    glVertex2f(127.9538738043822, 250.0221354789139);

    glVertex2f(143.9557602518358, 249.9519517664251);

    glVertex2f(144.0259439643247, 269.9543098257423);

    glVertex2f(128, 270);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(127.9538738043822, 250.0221354789139);

    glVertex2f(143.9557602518358, 249.9519517664251);

    glVertex2f(144.0259439643247, 269.9543098257423);

    glVertex2f(128, 270);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(127.9538738043822, 250.0221354789139);

    glVertex2f(128, 270);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(143.9557602518358, 249.9519517664251);

    glVertex2f(144.0259439643247, 269.9543098257423);

    glEnd();



     glColor3ub(232, 218, 239);

    glBegin(GL_POLYGON);

    glVertex2f(100,280);

    glVertex2f(115,280);

    glVertex2f(115.0953493806942, 300.0580739770991);

    glVertex2f(100,300);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

     glVertex2f(100,280);

    glVertex2f(115,280);

    glVertex2f(115.0953493806942, 300.0580739770991);

    glVertex2f(100,300);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100,280);

    glVertex2f(100,300);

    glEnd();

    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(115,280);

    glVertex2f(115.0953493806942, 300.0580739770991);

    glEnd();



     glColor3ub(232, 218, 239);

    glBegin(GL_POLYGON);

    glVertex2f(128.0231446873945, 280.075821492021);

    glVertex2f(143.9208994436586, 279.9119271130904);

    glVertex2f(143.9665400567093, 299.9714881338979);

    glVertex2f(127.9717143797515, 299.9714881338979);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(128.0231446873945, 280.075821492021);

    glVertex2f(143.9208994436586, 279.9119271130904);

    glVertex2f(143.9665400567093, 299.9714881338979);

    glVertex2f(127.9717143797515, 299.9714881338979);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(128.0231446873945, 280.075821492021);

    glVertex2f(127.9717143797515, 299.9714881338979);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

     glVertex2f(143.9208994436586, 279.9119271130904);

    glVertex2f(143.9665400567093, 299.9714881338979);

    glEnd();



   glColor3ub(232, 218, 239);
    glBegin(GL_POLYGON);

    glVertex2f(100,310);

    glVertex2f(115, 310);

    glVertex2f(115, 330);

    glVertex2f(100, 330);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100,310);

    glVertex2f(115, 310);

    glVertex2f(115, 330);

    glVertex2f(100, 330);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100,310);

    glVertex2f(100, 330);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(115, 310);

    glVertex2f(115, 330);

    glEnd();



  glColor3ub(232, 218, 239);
    glBegin(GL_POLYGON);

    glVertex2f(128.0402601239792, 310.1124012669486);

    glVertex2f(144.081056013881, 309.9478802834624);

    glVertex2f(144, 330);

    glVertex2f(128.0851911274517, 330.0531443954878);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(128.0402601239792, 310.1124012669486);

    glVertex2f(144.081056013881, 309.9478802834624);

    glVertex2f(144, 330);

    glVertex2f(128.0851911274517, 330.0531443954878);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(128.0402601239792, 310.1124012669486);

    glVertex2f(128.0851911274517, 330.0531443954878);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(144.081056013881, 309.9478802834624);

    glVertex2f(144, 330);

    glEnd();


 glColor3ub(232, 218, 239);

    glBegin(GL_POLYGON);

    glVertex2f(100,340);

    glVertex2f(115,340);

    glVertex2f(115, 360);

    glVertex2f(100,360);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100,340);

    glVertex2f(115,340);

    glVertex2f(115, 360);

    glVertex2f(100,360);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100,340);

    glVertex2f(100,360);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(115,340);

    glVertex2f(115, 360);

    glEnd();



     glColor3ub(232, 218, 239);

    glBegin(GL_POLYGON);

    glVertex2f(128.0304627004426, 340.0812430055494);

    glVertex2f(144, 340);

    glVertex2f(143.9682390389781, 359.9115823892981);

    glVertex2f(128.0953288526272, 359.9115823892981);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(128.0304627004426, 340.0812430055494);

    glVertex2f(144, 340);

    glVertex2f(143.9682390389781, 359.9115823892981);

    glVertex2f(128.0953288526272, 359.9115823892981);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(128.0304627004426, 340.0812430055494);

    glVertex2f(128.0953288526272, 359.9115823892981);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(144, 340);

    glVertex2f(143.9682390389781, 359.9115823892981);

    glEnd();



     glColor3ub(232, 218, 239);

    glBegin(GL_POLYGON);

    glVertex2f(100,370);

    glVertex2f(116.0353770362673, 369.8836199144383);

    glVertex2f(116, 390);

    glVertex2f(100, 390);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100,370);

    glVertex2f(116.0353770362673, 369.8836199144383);

    glVertex2f(116, 390);

    glVertex2f(100, 390);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(100,370);

    glVertex2f(100, 390);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(116.0353770362673, 369.8836199144383);

    glVertex2f(116, 390);

    glEnd();



     glColor3ub(232, 218, 239);
    glBegin(GL_POLYGON);

    glVertex2f(128.0729895389285, 370.0215889687379);

    glVertex2f(144, 370);

    glVertex2f(144, 390);

    glVertex2f(128, 390);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(128.0729895389285, 370.0215889687379);

    glVertex2f(144, 370);

    glVertex2f(144, 390);

    glVertex2f(128, 390);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(128.0729895389285, 370.0215889687379);

    glVertex2f(128, 390);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

     glVertex2f(144, 370);

    glVertex2f(144, 390);

    glEnd();



}



void buil2()

{



    glColor3ub(9, 126, 126);

    glBegin(GL_POLYGON);

    glVertex2f(150, 180);

    glVertex2f(240, 180);

    glVertex2f(240, 340);

    glVertex2f(149.9661158523671, 340.4891545706261);

    glVertex2f(150, 180);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

   glVertex2f(150, 180);

    glVertex2f(240, 180);

    glVertex2f(240, 340);

    glVertex2f(149.9661158523671, 340.4891545706261);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

   glVertex2f(150, 180);

   glVertex2f(149.9661158523671, 340.4891545706261);

   glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(240, 180);

    glVertex2f(240, 340);

    glEnd();



    glColor3ub(159, 226, 191);

    glBegin(GL_POLYGON);

    glVertex2f(209.8184760969489, 340.1148348643002);

    glVertex2f(240, 340);

    glVertex2f(240, 380);

    glVertex2f(210, 380);

    glVertex2f(209.8184760969489, 340.1148348643002);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(209.8184760969489, 340.1148348643002);

    glVertex2f(240, 340);

    glVertex2f(240, 380);

    glVertex2f(210, 380);

    glVertex2f(209.8184760969489, 340.1148348643002);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(209.8184760969489, 340.1148348643002);

    glVertex2f(210, 380);

       glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(240, 340);

    glVertex2f(240, 380);

    glEnd();



    glColor3ub( 95, 196, 196);

    glBegin(GL_POLYGON);

    glVertex2f(180,180);

    glVertex2f(210, 180);

    glVertex2f(210, 210);

    glVertex2f(180, 210);

    glVertex2f(180,180);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(180,180);

    glVertex2f(210, 180);

    glVertex2f(210, 210);

    glVertex2f(180, 210);

    glVertex2f(180,180);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(180,180);

    glVertex2f(180,210);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(210, 180);

    glVertex2f(210, 210);

    glEnd();





    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(156.6042396808212, 220.1620863799464);

    glVertex2f(180, 220);

    glVertex2f(180, 240);

    glVertex2f(156.6042396808212, 239.8043055431601);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(156.6042396808212, 220.1620863799464);

    glVertex2f(180, 220);

    glVertex2f(180, 240);

    glVertex2f(156.6042396808212, 239.8043055431601);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(156.6042396808212, 220.1620863799464);

    glVertex2f(156.6042396808212, 239.8043055431601);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(180, 220);

    glVertex2f(180, 240);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(204.0545444009446, 219.9413872882249);

    glVertex2f(230, 220);

    glVertex2f(230, 240);

    glVertex2f(204.0694021350863, 240.0220330880533);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(204.0545444009446, 219.9413872882249);

    glVertex2f(230, 220);

    glVertex2f(230, 240);

    glVertex2f(204.0694021350863, 240.0220330880533);

    glEnd();



      glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(204.0545444009446, 219.9413872882249);

    glVertex2f(204.0694021350863, 240.0220330880533);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(230, 220);

    glVertex2f(230, 240);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(156.8237092359748, 249.9770816616228);

    glVertex2f(180, 250);

    glVertex2f(180, 270);

    glVertex2f(156.8237092359749, 269.9403085148193);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(156.8237092359748, 249.9770816616228);

    glVertex2f(180, 250);

    glVertex2f(180, 270);

    glVertex2f(156.8237092359749, 269.9403085148193);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(156.8237092359748, 249.9770816616228);

    glVertex2f(156.8237092359749, 269.9403085148193);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(180, 250);

    glVertex2f(180, 270);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(204, 250);

    glVertex2f(230, 250);

    glVertex2f(230, 270);

    glVertex2f(204, 270);

    glEnd();



     glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(204, 250);

    glVertex2f(230, 250);

    glVertex2f(230, 270);

    glVertex2f(204, 270);

    glEnd();



     glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(204, 250);

     glVertex2f(204, 270);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);

    glVertex2f(230, 250);

    glVertex2f(230, 270);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(156.8237092359748, 249.9770816616228);

    glVertex2f(180, 250);

    glVertex2f(180, 270);

    glVertex2f(156.8237092359749, 269.9403085148193);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(204, 250);

    glVertex2f(230, 250);

    glVertex2f(230, 270);

    glVertex2f(204, 270);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(156.8871914273931, 279.9883389919396);

    glVertex2f(180, 280);

    glVertex2f(180, 300);

    glVertex2f(157.062980907708, 300.0417379134722);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(156.8871914273931, 279.9883389919396);

    glVertex2f(180, 280);

    glVertex2f(180, 300);

    glVertex2f(157.062980907708, 300.0417379134722);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(156.8871914273931, 279.9883389919396);

    glVertex2f(157.062980907708, 300.0417379134722);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(180, 280);

    glVertex2f(180, 300);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(204, 280);

    glVertex2f(230, 280);

    glVertex2f(230, 300);

    glVertex2f(204, 300);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(204, 280);

    glVertex2f(230, 280);

    glVertex2f(230, 300);

    glVertex2f(204, 300);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(204, 280);

    glVertex2f(204, 300);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(230, 280);

    glVertex2f(230, 300);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(157.062980907708, 310.0629672056268);

    glVertex2f(180, 310);

    glVertex2f(180, 330);

    glVertex2f(157.062980907708, 329.9777668180612);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(157.062980907708, 310.0629672056268);

    glVertex2f(180, 310);

    glVertex2f(180, 330);

    glVertex2f(157.062980907708, 329.9777668180612);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(157.062980907708, 310.0629672056268);

    glVertex2f(157.062980907708, 329.9777668180612);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(180, 310);

    glVertex2f(180, 330);

    glEnd();



    glColor3ub( 132, 176, 176);

    glBegin(GL_POLYGON);

    glVertex2f(204, 310);

    glVertex2f(230, 310);

    glVertex2f(230, 330);

    glVertex2f(204, 330);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(204, 310);

    glVertex2f(230, 310);

    glVertex2f(230, 330);

    glVertex2f(204, 330);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(204, 310);

    glVertex2f(204, 330);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);

    glVertex2f(230, 310);

    glVertex2f(230, 330);

    glEnd();

}



void buil3()

{



    glColor3ub(229, 152, 102);

    glBegin(GL_POLYGON);

    glVertex2f(250, 180);

    glVertex2f(350, 180);

    glVertex2f(350, 400);

    glVertex2f(250, 400);

    glVertex2f(250, 180);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(250, 180);

    glVertex2f(350, 180);

    glVertex2f(350, 400);

    glVertex2f(250, 400);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(250, 180);

    glVertex2f(250, 400);

    glEnd();



    glLineWidth(2);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(350, 180);

    glVertex2f(350, 400);

    glEnd();



    glColor3ub(211, 84, 0);

    glBegin(GL_POLYGON);

    glVertex2f(280,180);

    glVertex2f(320,180);

    glVertex2f(320, 220);

    glVertex2f(280, 220);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(280,180);

    glVertex2f(320,180);

    glVertex2f(320, 220);

    glVertex2f(280, 220);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(280,180);

    glVertex2f(280, 220);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(320,180);

    glVertex2f(320, 220);

    glEnd();



    glColor3ub(235, 152, 78);

    glBegin(GL_POLYGON);

    glVertex2f(260, 280);

    glVertex2f(300, 280);

    glVertex2f(300, 300);

    glVertex2f(260, 300);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(260, 280);

    glVertex2f(300, 280);

    glVertex2f(300, 300);

    glVertex2f(260, 300);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(260, 280);

    glVertex2f(260, 300);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 280);

    glVertex2f(300, 300);

    glEnd();



    glColor3ub(250, 215, 160);

    glBegin(GL_POLYGON);

    glVertex2f(300, 280);

    glVertex2f(340, 280);

    glVertex2f(340, 300);

    glVertex2f(300, 300);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 280);

    glVertex2f(340, 280);

    glVertex2f(340, 300);

    glVertex2f(300, 300);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 280);

    glVertex2f(300, 300);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(340, 280);

    glVertex2f(340, 300);

    glEnd();



    glColor3ub(250, 215, 160);

    glBegin(GL_POLYGON);

    glVertex2f(260, 320);

    glVertex2f(300, 320);

    glVertex2f(300, 340);

    glVertex2f(260, 340);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(260, 320);

    glVertex2f(300, 320);

    glVertex2f(300, 340);

    glVertex2f(260, 340);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(260, 320);

    glVertex2f(260, 340);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 320);

    glVertex2f(300, 340);

    glEnd();



    glColor3ub(235, 152, 78);

    glBegin(GL_POLYGON);

    glVertex2f(300, 320);

    glVertex2f(340, 320);

    glVertex2f(340, 340);

    glVertex2f(300, 340);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 320);

    glVertex2f(340, 320);

    glVertex2f(340, 340);

    glVertex2f(300, 340);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 320);

    glVertex2f(300, 340);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(340, 320);

    glVertex2f(340, 340);

    glEnd();



    glColor3ub(235, 152, 78);

    glBegin(GL_POLYGON);

    glVertex2f(260, 360);

    glVertex2f(300, 360);

    glVertex2f(300, 380);

    glVertex2f(260, 380);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(260, 360);

    glVertex2f(300, 360);

    glVertex2f(300, 380);

    glVertex2f(260, 380);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(260, 360);

    glVertex2f(260, 380);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 360);

    glVertex2f(300, 380);

    glEnd();



    glColor3ub(250, 215, 160);

    glBegin(GL_POLYGON);

    glVertex2f(300, 360);

    glVertex2f(340, 360);

    glVertex2f(340, 380);

    glVertex2f(300, 380);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 360);

    glVertex2f(340, 360);

    glVertex2f(340, 380);

    glVertex2f(300, 380);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(300, 360);

    glVertex2f(300, 380);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(340, 360);

    glVertex2f(340, 380);

    glEnd();

}



void buil4()

{

  glColor3ub(20, 52, 164);

    glBegin(GL_POLYGON);

    glVertex2f(350, 180);

    glVertex2f(460, 180);

    glVertex2f(460, 200);

    glVertex2f(350.0256082550327, 199.9800870976858);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(350, 180);

    glVertex2f(460, 180);

    glVertex2f(460, 200);

    glVertex2f(350.0256082550327, 199.9800870976858);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(350, 180);

    glVertex2f(350.0256082550327, 199.9800870976858);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(460, 180);

    glVertex2f(460, 200);

    glEnd();



    glColor3ub(64, 181, 173);

    glBegin(GL_POLYGON);

    glVertex2f(354.437,200);

    glVertex2f(456.019, 200);

    glVertex2f(455.887,380.368);

    glVertex2f(354.14, 380.284);

    glEnd();



     glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(354.437,200);

    glVertex2f(456.019, 200);

    glVertex2f(455.887,380.368);

    glVertex2f(354.14, 380.284);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(354.437,200);

    glVertex2f(354.14, 380.284);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(456.019, 200);

    glVertex2f(455.887,380.368);

    glEnd();



    glColor3ub(20, 52, 164);

    glBegin(GL_POLYGON);

    glVertex2f(354.14, 380.284);

    glVertex2f(455.887,380.368);

    glVertex2f(440,400);

    glVertex2f(370,400);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(354.14, 380.284);

    glVertex2f(455.887,380.368);

    glVertex2f(440,400);

    glVertex2f(370,400);

    glEnd();



     glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(354.14, 380.284);

    glVertex2f(370,400);

    glEnd();



     glLineWidth(1.5);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(455.887,380.368);

    glVertex2f(440,400);

    glEnd();



    glColor3ub(115, 147, 179);

    glBegin(GL_POLYGON);

    glVertex2f(368.8228890084603, 368.2885989402066);

    glVertex2f(443.7906811797685, 368.2154808929749);

    glVertex2f(443.91102181917955, 328.2415947744908);

    glVertex2f(368.82288900846027, 328.49188855052654);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(368.8228890084603, 368.2885989402066);

    glVertex2f(443.7906811797685, 368.2154808929749);

    glVertex2f(443.91102181917955, 328.2415947744908);

    glVertex2f(368.82288900846027, 328.49188855052654);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(368.8228890084603, 368.2885989402066);

    glVertex2f(368.82288900846027, 328.49188855052654);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(443.7906811797685, 368.2154808929749);

    glVertex2f(443.91102181917955, 328.2415947744908);

    glEnd();



    glColor3ub(182, 208, 226);

    glBegin(GL_POLYGON);

    glVertex2f(380, 340);

    glVertex2f(400, 340);

    glVertex2f(400, 360);

    glVertex2f(380, 360);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(380, 340);

    glVertex2f(400, 340);

    glVertex2f(400, 360);

    glVertex2f(380, 360);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(380, 340);

    glVertex2f(380, 360);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(400, 340);

    glVertex2f(400, 360);

    glEnd();



    glColor3ub(182, 208, 226);

    glBegin(GL_POLYGON);

    glVertex2f(415.8781189031778, 340.0054022481698);

    glVertex2f(436.1519147620719, 340.2556960242055);

    glVertex2f(436.1519147620719, 360.0289043310277);

    glVertex2f(415.6278251271419, 359.778610554992);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

   glVertex2f(415.8781189031778, 340.0054022481698);

    glVertex2f(436.1519147620719, 340.2556960242055);

    glVertex2f(436.1519147620719, 360.0289043310277);

    glVertex2f(415.6278251271419, 359.778610554992);

    glEnd();



      glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

   glVertex2f(415.8781189031778, 340.0054022481698);

    glVertex2f(415.6278251271419, 359.778610554992);

    glEnd();



      glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(436.1519147620719, 340.2556960242055);

    glVertex2f(436.1519147620719, 360.0289043310277);

    glEnd();



    glColor3ub(115, 147, 179);

    glBegin(GL_POLYGON);

    glVertex2f(368.0720076803532, 280.1851897756318);

    glVertex2f(444.110305509963, 280.25335328823);

    glVertex2f(444.2549423510362, 315.8340161922381);

    glVertex2f(367.8217139043175, 315.7269059727046);

    glEnd();



      glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

   glVertex2f(368.0720076803532, 280.1851897756318);

    glVertex2f(444.110305509963, 280.25335328823);

    glVertex2f(444.2549423510362, 315.8340161922381);

    glVertex2f(367.8217139043175, 315.7269059727046);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

   glVertex2f(368.0720076803532, 280.1851897756318);

    glVertex2f(367.8217139043175, 315.7269059727046);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(444.110305509963, 280.25335328823);

    glVertex2f(444.2549423510362, 315.8340161922381);

    glEnd();



    glColor3ub(182, 208, 226);

    glBegin(GL_POLYGON);

    glVertex2f(380.1454572282847, 288.2741606517918);

    glVertex2f(400.0168678338659, 288.2741606517918);

    glVertex2f(399.8818109325508, 307.8285121298797);

    glVertex2f(379.9574569740642, 307.6820095272437);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(380.1454572282847, 288.2741606517918);

    glVertex2f(400.0168678338659, 288.2741606517918);

    glVertex2f(399.8818109325508, 307.8285121298797);

    glVertex2f(379.9574569740642, 307.6820095272437);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(380.1454572282847, 288.2741606517918);

    glVertex2f(379.9574569740642, 307.6820095272437);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(400.0168678338659, 288.2741606517918);

    glVertex2f(399.8818109325508, 307.8285121298797);

    glEnd();



    glColor3ub(182, 208, 226);

    glBegin(GL_POLYGON);

    glVertex2f(416.1700756050801, 288.334447467648);

    glVertex2f(436.0668141614519, 288.3003939774849);

    glVertex2f(435.827846860248, 307.6609079713238);

    glVertex2f(416.2467625959364, 307.5074542574691);

    glEnd();



     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(416.1700756050801, 288.334447467648);

    glVertex2f(436.0668141614519, 288.3003939774849);

    glVertex2f(435.827846860248, 307.6609079713238);

    glVertex2f(416.2467625959364, 307.5074542574691);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(416.1700756050801, 288.334447467648);

    glVertex2f(416.2467625959364, 307.5074542574691);

    glEnd();



    glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(436.0668141614519, 288.3003939774849);

    glVertex2f(435.827846860248, 307.6609079713238);

    glEnd();





    glColor3ub(182, 208, 226);

    glBegin(GL_POLYGON);

    glVertex2f(387.9284336133121, 200.5555631721265);

    glVertex2f(428.098,200);

    glVertex2f(428.1883722770751, 259.9995985838557);

    glVertex2f(387.919470388423, 259.912401464995);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

     glVertex2f(387.9284336133121, 200.5555631721265);

    glVertex2f(428.098,200);

    glVertex2f(428.1883722770751, 259.9995985838557);

    glVertex2f(387.919470388423, 259.912401464995);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

     glVertex2f(387.9284336133121, 200.5555631721265);

    glVertex2f(387.919470388423, 259.912401464995);

    glEnd();





     glLineWidth(1);

    glBegin(GL_LINES);///lines5

    glColor3ub(0,0,0);

    glVertex2f(428.098,200);

    glVertex2f(428.1883722770751, 259.9995985838557);

    glEnd();

}



void road1()

{

    glColor3ub(105, 105, 105);

    glBegin(GL_POLYGON);

    glColor3ub(1, 1, 1);
    glVertex2f(220,150);

    glVertex2f(220,50);

    glColor3ub(105, 105, 105);

    glVertex2f(260,50);

    glVertex2f(260,150);

    glVertex2f(570,150);

    glVertex2f(570,180);

    glVertex2f(0,180);

    glVertex2f(0,150);

    glEnd();

    glLineWidth(5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(0,170);

    glVertex2f(50, 170);

    glEnd();



    glLineWidth(5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(70,170);

    glVertex2f(120, 170);

    glEnd();



    glLineWidth(5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(140,170);

    glVertex2f(190, 170);

    glEnd();



    glLineWidth(5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(70,170);

    glVertex2f(120, 170);

    glEnd();



    glLineWidth(5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(220,170);

    glVertex2f(280, 170);

    glEnd();



    glLineWidth(5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(310,170);

    glVertex2f(380, 170);

    glEnd();



    glLineWidth(5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(410,170);

    glVertex2f(470, 170);

    glEnd();



     glLineWidth(7);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(240,145);

    glVertex2f(240, 75);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255, 255, 255);

    glVertex2f(0,150);

    glVertex2f(220, 150);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(220,150);

    glVertex2f(220, 50);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(260,50);

    glVertex2f(260, 150);

    glEnd();



    glLineWidth(1.5);

    glBegin(GL_LINES);///lines1

    glColor3ub(255,255,255);

    glVertex2f(260,150);

    glVertex2f(560, 150);

    glEnd();

}



// Front Road

void road()

{

    glColor3ub(0, 128, 0);

    glBegin(GL_POLYGON);

    glVertex2f(0, 0);

    glVertex2f(500, 0);

    glVertex2f(500, 75);

    glVertex2f(0, 75);

    glEnd();

    // car road

    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(0, 0);

    glVertex2f(500, 0);

    glVertex2f(500, 55);

    glVertex2f(0, 55);

    glEnd();

    glColor3ub(105, 105, 105);

    glBegin(GL_POLYGON);

    glVertex2f(0, 0);

    glVertex2f(500, 0);

    glVertex2f(500, 50);

    glVertex2f(0, 50);

    glEnd();

    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(15, 20);

    glVertex2f(50, 20);

    glVertex2f(50, 30);

    glVertex2f(15, 30);

    glEnd();

    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(65, 20);

    glVertex2f(100, 20);

    glVertex2f(100, 30);

    glVertex2f(65, 30);

    glEnd();



    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(115, 20);

    glVertex2f(150, 20);

    glVertex2f(150, 30);

    glVertex2f(115, 30);

    glEnd();



    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(165, 20);

    glVertex2f(200, 20);

    glVertex2f(200, 30);

    glVertex2f(165, 30);

    glEnd();



    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(215, 20);

    glVertex2f(250, 20);

    glVertex2f(250, 30);

    glVertex2f(215, 30);

    glEnd();



    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(265, 20);

    glVertex2f(300, 20);

    glVertex2f(300, 30);

    glVertex2f(265, 30);

    glEnd();



    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(315, 20);

    glVertex2f(350, 20);

    glVertex2f(350, 30);

    glVertex2f(315, 30);

    glEnd();



    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(365, 20);

    glVertex2f(400, 20);

    glVertex2f(400, 30);

    glVertex2f(365, 30);

    glEnd();



    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(415, 20);

    glVertex2f(450, 20);

    glVertex2f(450, 30);

    glVertex2f(415, 30);

    glEnd();



    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(465, 20);

    glVertex2f(500, 20);

    glVertex2f(500, 30);

    glVertex2f(465, 30);

    glEnd();



}

float  tx = 10, bx = 10, rx = 10, sx = 10, hx = 0;



void circle(float rx, float ry, float cx, float cy)

{

    glBegin(GL_POLYGON);

    glVertex2f(cx, cy);

    for (int i = 0; i <= 360; i++)

    {

        float angle = i * 3.1416 / 180;

        float x = rx * cos(angle);

        float y = ry * sin(angle);

        glVertex2f((x + cx), (y + cy));

    }

    glEnd();

}



void Bushes()

{

    // 1st Bushes

    glColor3ub(154, 205, 50);

    circle(20, 30, 20, 180);

    circle(20, 30, 40, 210);

    circle(20, 30, 60, 180);



    // 2nd Bushes

    glColor3ub(154, 205, 50);

    circle(20, 30, 430, 180);

    circle(20, 30, 450, 210);

    circle(20, 30, 470, 180);



    // 3rd Bushes

    glColor3ub(0, 128, 0);

    circle(20, 30, 490, 180);

    circle(20, 30, 510, 210);

}



void sun()

{

    glBegin(GL_POLYGON);

 glBegin(GL_POLYGON);
  float x22 = 305;
  float y22= 452;
  for (int i = 0; i < 300; i++)
  {
       glColor3ub(255, 234, 0);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 30;
       float x = r * cos(a) + x22;
       float y = r * sin(a) + y22;
       glVertex2f(x, y);
  }
  glEnd();

  glBegin(GL_POLYGON);


}



void round(GLfloat rx, GLfloat ry, GLfloat cx, GLfloat cy)

{

    glBegin(GL_POLYGON);

    glVertex2f(cx, cy);

    for (int i = 0; i <= 360; i++)

    {

        float angle = i * 3.1416 / 180;

        float x = rx * cos(angle);

        float y = ry * sin(angle);

        glVertex2f((x + cx), (y + cy));

    }

    glEnd();

}



float shift = 0; // a variable used to move the clouds right and left

void init(void)

{

    glClearColor(0, 0.9, 0.9, 0);

    glMatrixMode(GL_PROJECTION);

    gluOrtho2D(0, 500, 0, 500);

}

void tree()

{

    // back tree

    glColor3ub(139, 69, 19);

    glBegin(GL_POLYGON);

    glVertex2f(30, 180);

    glVertex2f(40, 180);

    glVertex2f(40, 320);

    glVertex2f(30, 320);

    glEnd();

     glLineWidth(1);

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);
    glVertex2f(30, 180);
    glVertex2f(40, 180);
    glVertex2f(40, 320);
    glVertex2f(30, 320);
    glEnd();

    glBegin(GL_LINES);///lines1

    glColor3ub(0,0,0);
    glVertex2f(30, 180);
    glVertex2f(30, 320);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(40, 180);
    glVertex2f(40, 320);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(20, 335);
    glVertex2f(0, 310);
    glVertex2f(70, 310);
    glVertex2f(50, 335);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(20, 335);
    glVertex2f(0, 310);
    glVertex2f(70, 310);
    glVertex2f(50, 335);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(20, 335);
    glVertex2f(50, 335);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(0, 310);
    glVertex2f(70, 310);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(20, 360);
    glVertex2f(0, 335);
    glVertex2f(73, 335);
    glVertex2f(50, 360);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(20, 360);
    glVertex2f(0, 335);
    glVertex2f(73, 335);
    glVertex2f(50, 360);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(20, 360);
    glVertex2f(50, 360);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(0, 335);
    glVertex2f(73, 335);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(0, 360);
    glVertex2f(70, 360);
    glVertex2f(35, 399);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(0, 360);
    glVertex2f(70, 360);
    glVertex2f(35, 399);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(0, 360);
    glVertex2f(35, 399);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(70, 360);
    glVertex2f(35, 399);
    glEnd();

    glColor3ub(139, 69, 19);
    glBegin(GL_POLYGON);
    glVertex2f(48, 180);
    glVertex2f(52, 180);
    glVertex2f(52, 230);
    glVertex2f(48,230);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(48, 180);
    glVertex2f(52, 180);
    glVertex2f(52, 230);
    glVertex2f(48,230);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(48, 180);
    glVertex2f(48,230);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(52, 180);
    glVertex2f(52, 230);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(45, 240);
    glVertex2f(40, 230);
    glVertex2f(60, 230);
    glVertex2f(55,240);
    glEnd();

     glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(45, 240);
    glVertex2f(40, 230);
    glVertex2f(60, 230);
    glVertex2f(55,240);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(45, 240);
    glVertex2f(55,240);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(40, 230);
    glVertex2f(60, 230);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(45, 250);
    glVertex2f(40, 240);
    glVertex2f(60 ,240);
    glVertex2f(55,250);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(45, 250);
    glVertex2f(40, 240);
    glVertex2f(60 ,240);
    glVertex2f(55,250);
    glEnd();

     glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(45, 250);
    glVertex2f(55,250);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(40, 240);
    glVertex2f(60 ,240);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(50, 265);
    glVertex2f(40, 250);
    glVertex2f(60 ,250);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(50, 265);
    glVertex2f(40, 250);
    glVertex2f(60 ,250);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(50, 265);
    glVertex2f(60 ,250);
    glEnd();

    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(40, 250);
    glVertex2f(60 ,250);
    glEnd();

    glColor3ub(1, 1, 1);
    glBegin(GL_POLYGON);
    glVertex2f(82, 180);
    glVertex2f(86, 180);
    glVertex2f(86 ,340);
    glVertex2f(82,340);
    glEnd();

    glColor3ub(255, 255, 255);
    glBegin(GL_POLYGON);
    glVertex2f(72, 363);
    glVertex2f(77, 340);
    glVertex2f(90 ,340);
    glVertex2f(95,363);
    glEnd();

    glColor3ub(1, 1, 1);
    glBegin(GL_POLYGON);
    glVertex2f(83, 377);
    glVertex2f(72, 363);
    glVertex2f(95 ,363);
    glEnd();

    glColor3ub(139, 69, 19);///
    glBegin(GL_POLYGON);
    glVertex2f(66, 180);
    glVertex2f(74, 180);
    glVertex2f(74 ,270);
    glVertex2f(66,270);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(66, 180);
    glVertex2f(74, 180);
    glVertex2f(74 ,270);
    glVertex2f(66,270);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(66, 180);
    glVertex2f(66,270);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(74, 180);
    glVertex2f(74 ,270);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(60, 280);
    glVertex2f(50, 270);
    glVertex2f(90 ,270);
    glVertex2f(80,280);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(60, 280);
    glVertex2f(50, 270);
    glVertex2f(90 ,270);
    glVertex2f(80,280);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(60, 280);
    glVertex2f(80,280);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(50, 270);
    glVertex2f(90 ,270);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(60, 290);
    glVertex2f(50, 280);
    glVertex2f(90 ,280);
    glVertex2f(80,290);
    glEnd();

     glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(60, 290);
    glVertex2f(50, 280);
    glVertex2f(90 ,280);
    glVertex2f(80,290);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(60, 290);
    glVertex2f(80,290);
    glEnd();

    glLineWidth(1);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(50, 280);
    glVertex2f(90 ,280);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(70, 310);
    glVertex2f(50, 290);
    glVertex2f(90 ,290);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(70, 310);
    glVertex2f(50, 290);
    glVertex2f(90 ,290);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(50, 290);
    glVertex2f(90 ,290);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(70, 310);
    glVertex2f(90 ,290);
    glEnd();

    glColor3ub(139, 69, 19);///
    glBegin(GL_POLYGON);
    glVertex2f(12, 180);
    glVertex2f(20, 180);
    glVertex2f(20 ,260);
    glVertex2f(12,260);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(12, 180);
    glVertex2f(20, 180);
    glVertex2f(20 ,260);
    glVertex2f(12,260);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(12, 180);
    glVertex2f(12,260);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(20, 180);
    glVertex2f(20 ,260);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(10, 270);
    glVertex2f(0, 260);
    glVertex2f(30 ,260);
    glVertex2f(20,270);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(10, 270);
    glVertex2f(0, 260);
    glVertex2f(30 ,260);
    glVertex2f(20,270);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(10, 270);
    glVertex2f(20,270);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(0, 260);
    glVertex2f(30 ,260);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(10, 280);
    glVertex2f(0, 270);
    glVertex2f(30 ,270);
    glVertex2f(20,280);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(10, 280);
    glVertex2f(0, 270);
    glVertex2f(30 ,270);
    glVertex2f(20,280);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(10, 280);
    glVertex2f(20,280);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(0, 270);
    glVertex2f(30 ,270);
    glEnd();

    glColor3ub(34, 139, 34);
    glBegin(GL_POLYGON);
    glVertex2f(15, 297);
    glVertex2f(0, 280);
    glVertex2f(30 ,280);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(15, 297);
    glVertex2f(0, 280);
    glVertex2f(30 ,280);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(15, 297);
    glVertex2f(30 ,280);
    glEnd();

    glLineWidth(0.9);
    glBegin(GL_LINES);///lines1
    glColor3ub(0,0,0);
    glVertex2f(0, 280);
    glVertex2f(30 ,280);
    glEnd();
}


void clouds2()

{

    glPushMatrix();

    glTranslatef(rx, 0, 0);

    // 1st cloud

    glColor3ub(220, 220, 220);

    circle(20, 30, 460, 460);

    circle(15, 20, 445, 460);

    circle(15, 20, 475, 460);

    // 2nd cloud



    circle(20, 30, 390, 420);

    circle(15, 20, 405, 420);

    circle(15, 20, 375, 420);



    glPopMatrix();

    glutPostRedisplay();

}

void clouds()

{

    // 1st cloud

    glColor3ub(255, 255, 255);

    round(20, 30, 90, 460);

    round(15, 20, 110, 460);

    round(15, 20, 70 , 460);

    // 2nd cloud

    round(20, 30, 185 , 430);

    round(15, 20, 205 , 430);

    round(15, 20, 165 , 430);

}



void car() {



    glColor3ub(0, 0, 0);

    glBegin(GL_POLYGON);

    glVertex2f(410, 40);

    glVertex2f(490, 40);

    glVertex2f(485, 70);

    glVertex2f(410, 70);

    glEnd();



    glColor3ub(0, 0, 0);

    glBegin(GL_POLYGON);

    glVertex2f(420, 70);

    glVertex2f(475, 70);

    glVertex2f(465, 100);

    glVertex2f(430, 100);

    glEnd();



    // car window

    glColor3ub(220, 220, 220);

    glBegin(GL_POLYGON);

    glVertex2f(425, 70);

    glVertex2f(445, 70);

    glVertex2f(445, 90);

    glVertex2f(430, 90);

    glEnd();



    // car window

    glColor3ub(220, 220, 220);

    glBegin(GL_POLYGON);

    glVertex2f(450, 70);

    glVertex2f(470, 70);

    glVertex2f(465, 90);

    glVertex2f(450, 90);

    glEnd();



    // car wheel

    glColor3ub(0, 0, 0);

    circle(10, 14, 435, 40);

    circle(10, 14, 465, 40);



    glColor3ub(245, 245, 245);

    circle(6, 10, 435, 40);

    circle(6, 10, 465, 40);


}



void truck() {

    glColor3ub(212, 172, 13 );

    glBegin(GL_POLYGON);

    glVertex2f(30, 40);

    glVertex2f(85, 40);

    glVertex2f(85, 110);

    glVertex2f(30, 110);

    glEnd();



    glColor3ub(220, 20, 60);

    glBegin(GL_POLYGON);

    glVertex2f(85, 40);

    glVertex2f(115, 40);

    glVertex2f(115, 70);

    glVertex2f(85, 70);

    glEnd();



    glColor3ub(220, 20, 60);

    glBegin(GL_POLYGON);

    glVertex2f(85, 70);

    glVertex2f(105, 70);

    glVertex2f(95, 90);

    glVertex2f(85, 90);

    glEnd();

    // window

    glColor3ub(220, 220, 220);

    glBegin(GL_POLYGON);

    glVertex2f(85, 70);

    glVertex2f(100, 70);

    glVertex2f(95, 85);

    glVertex2f(85, 85);

    glEnd();

    // wheels

    glColor3ub(0, 0, 0);

    circle(10, 14, 50, 40);

    circle(10, 14, 100, 40);



    glColor3ub(245, 245, 245);

    circle(6, 10, 50, 40);

    circle(6, 10, 100, 40);

}


void building_car()
{

     glColor3ub(185, 37, 4);
    glBegin(GL_POLYGON);
    glVertex2f(76, 183);
    glVertex2f(76, 165);
    glVertex2f(136, 165);
    glVertex2f(136, 183);
    glEnd();

    glColor3ub(185, 37, 4);
    glBegin(GL_POLYGON);
    glVertex2f(95, 200);
    glVertex2f(83, 183);
    glVertex2f(130, 183);
    glVertex2f(119, 200);
    glEnd();

///wheels
 glBegin(GL_POLYGON);
  float x1 =88;
  float y1= 165;
  for (int i = 0; i < 300; i++)
  {
       glColor3ub(0,0,0);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 9.38;
       float x = r * cos(a) + x1;
       float y = r * sin(a) + y1;
       glVertex2f(x, y);
  }
  glEnd();

 glBegin(GL_POLYGON);
  float x2 = 88;
  float y2= 165;
  for (int i = 0; i < 300; i++)
  {
       glColor3ub(255,255,255);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 6.13;
       float x = r * cos(a) + x2;
       float y = r * sin(a) + y2;
       glVertex2f(x, y);
  }
  glEnd();

   glBegin(GL_POLYGON);
  float x3 = 124;
  float y3= 165;
  for (int i = 0; i < 300; i++)
  {
       glColor3ub(0,0,0);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 9.38;
       float x = r * cos(a) + x3;
       float y = r * sin(a) + y3;
       glVertex2f(x, y);
  }
  glEnd();
 glBegin(GL_POLYGON);
  float x6 =124;
  float y6= 165;
  for (int i = 0; i < 300; i++)
  {
       glColor3ub(255,255,255);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 6.13;
       float x = r * cos(a) + x6;
       float y = r * sin(a) + y6;
       glVertex2f(x, y);
  }
  glEnd();
  ///windows
  glColor3ub(255,255,255);
    glBegin(GL_POLYGON);
    glVertex2f(94,195);
    glVertex2f(90,182);
    glVertex2f(104,182);
    glVertex2f(104,195);
    glEnd();
      glColor3ub(255,255,255);
    glBegin(GL_POLYGON);
    glVertex2f(107,195);
    glVertex2f(107,182);
    glVertex2f(122,182);
    glVertex2f(118,195);
    glEnd();
}

void little_tree()

{


    // 3rd tree

    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(5, 60);

    glVertex2f(0, 80);

    glVertex2f(7, 70);

    glVertex2f(7, 85);

    glVertex2f(12,70);

    glVertex2f(15,83);

    glVertex2f(17,70);

    glVertex2f(22,83);

    glVertex2f(21,70);

    glVertex2f(30,80);

    glVertex2f(24,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(40, 60);

    glVertex2f(33, 80);

    glVertex2f(41, 71);

    glVertex2f(41, 82);

    glVertex2f(45,70);

    glVertex2f(46,83);

    glVertex2f(49,70);

    glVertex2f(53,82);

    glVertex2f(53,70);

    glVertex2f(60,80);

    glVertex2f(54,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(75, 60);

    glVertex2f(68, 80);

    glVertex2f(76, 71);

    glVertex2f(76, 82);

    glVertex2f(80,70);

    glVertex2f(81,83);

    glVertex2f(84,70);

    glVertex2f(88,82);

    glVertex2f(88,70);

    glVertex2f(95,80);

    glVertex2f(89,60);

    glEnd();





    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(110, 60);

    glVertex2f(103, 80);

    glVertex2f(111, 71);

    glVertex2f(111, 82);

    glVertex2f(115,70);

    glVertex2f(116,83);

    glVertex2f(119,70);

    glVertex2f(123,82);

    glVertex2f(123,70);

    glVertex2f(130,80);

    glVertex2f(124,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(145, 60);

    glVertex2f(138, 80);

    glVertex2f(146, 71);

    glVertex2f(146, 82);

    glVertex2f(150,70);

    glVertex2f(151,83);

    glVertex2f(154,70);

    glVertex2f(158,82);

    glVertex2f(158,70);

    glVertex2f(165,80);

    glVertex2f(159,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(180, 60);

    glVertex2f(173, 80);

    glVertex2f(181, 71);

    glVertex2f(181, 82);

    glVertex2f(185,70);

    glVertex2f(186,83);

    glVertex2f(189,70);

    glVertex2f(193,82);

    glVertex2f(193,70);

    glVertex2f(200,80);

    glVertex2f(194,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(285, 60);

    glVertex2f(278, 80);

    glVertex2f(286, 71);

    glVertex2f(286, 82);

    glVertex2f(290,70);

    glVertex2f(291,83);

    glVertex2f(294,70);

    glVertex2f(298,82);

    glVertex2f(298,70);

    glVertex2f(305,80);

    glVertex2f(299,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(320, 60);

    glVertex2f(313, 80);

    glVertex2f(321, 71);

    glVertex2f(321, 82);

    glVertex2f(325,70);

    glVertex2f(326,83);

    glVertex2f(329,70);

    glVertex2f(333,82);

    glVertex2f(333,70);

    glVertex2f(340,80);

    glVertex2f(334,60);

    glEnd();



     glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(355, 60);

    glVertex2f(348, 80);

    glVertex2f(356, 71);

    glVertex2f(356, 82);

    glVertex2f(360,70);

    glVertex2f(361,83);

    glVertex2f(364,70);

    glVertex2f(368,82);

    glVertex2f(368,70);

    glVertex2f(375,80);

    glVertex2f(369,60);

    glEnd();



     glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(390, 60);

    glVertex2f(383, 80);

    glVertex2f(391, 71);

    glVertex2f(391, 82);

    glVertex2f(395,70);

    glVertex2f(396,83);

    glVertex2f(399,70);

    glVertex2f(403,82);

    glVertex2f(403,70);

    glVertex2f(410,80);

    glVertex2f(404,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(425, 60);

    glVertex2f(418, 80);

    glVertex2f(426, 71);

    glVertex2f(426, 82);

    glVertex2f(430,70);

    glVertex2f(431,83);

    glVertex2f(434,70);

    glVertex2f(438,82);

    glVertex2f(438,70);

    glVertex2f(445,80);

    glVertex2f(439,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(460, 60);

    glVertex2f(453, 80);

    glVertex2f(461, 71);

    glVertex2f(461, 82);

    glVertex2f(465,70);

    glVertex2f(466,83);

    glVertex2f(469,70);

    glVertex2f(473,82);

    glVertex2f(473,70);

    glVertex2f(480,80);

    glVertex2f(474,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(495, 60);

    glVertex2f(488, 80);

    glVertex2f(496, 71);

    glVertex2f(496, 82);

    glVertex2f(500,70);

    glVertex2f(501,83);

    glVertex2f(504,70);

    glVertex2f(508,82);

    glVertex2f(508,70);

    glVertex2f(515,80);

    glVertex2f(509,60);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(20, 125);

    glVertex2f(15, 120);

    glVertex2f(50, 120);

    glVertex2f(45, 125);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(30, 60);

    glVertex2f(35, 60);

    glVertex2f(35, 120);

    glVertex2f(30, 120);

    glEnd();



    glBegin(GL_POLYGON);

  float x2 = 33;

  float y2= 135;

  for (int i = 0; i < 300; i++)

  {

       glColor3ub(255, 255, 255);

       float pi = 3.1416;

       float a = (i * 2 * pi) / 300;

       float r = 10.25;

       float x = r * cos(a) + x2;

       float y = r * sin(a) + y2;

       glVertex2f(x, y);

  }

  glEnd();



  glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(90, 125);

    glVertex2f(85, 120);

    glVertex2f(120, 120);

    glVertex2f(115, 125);

    glEnd();



     glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(100, 60);

    glVertex2f(105, 60);

    glVertex2f(105, 120);

    glVertex2f(100, 120);

    glEnd();



    glBegin(GL_POLYGON);

 glBegin(GL_POLYGON);
  float x3 = 103;
  float y3= 135;
  for (int i = 0; i < 300; i++)
  {
        glColor3ub(255, 255, 255);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 10.25;
       float x = r * cos(a) + x3;
       float y = r * sin(a) + y3;
       glVertex2f(x, y);
  }
  glEnd();




  glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(170, 60);

    glVertex2f(175, 60);

    glVertex2f(175, 120);

    glVertex2f(170, 120);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(160, 125);

    glVertex2f(155, 120);

    glVertex2f(190, 120);

    glVertex2f(185, 125);

    glEnd();



    glBegin(GL_POLYGON);
  float x4 = 173;
  float y4= 135;
  for (int i = 0; i < 300; i++)
  {
        glColor3ub(255, 255, 255);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 10.25;
       float x = r * cos(a) + x4;
       float y = r * sin(a) + y4;
       glVertex2f(x, y);
  }
  glEnd();


   glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(310, 60);

    glVertex2f(315, 60);

    glVertex2f(315, 120);

    glVertex2f(310, 120);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(300, 125);

    glVertex2f(295, 120);

    glVertex2f(330, 120);

    glVertex2f(325, 125);

    glEnd();



     glBegin(GL_POLYGON);
  float x5 = 313;
  float y5= 135;
  for (int i = 0; i < 300; i++)
  {
         glColor3ub(255, 255, 255);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 10.25;
       float x = r * cos(a) + x5;
       float y = r * sin(a) + y5;
       glVertex2f(x, y);
  }
  glEnd();


   glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(380, 60);

    glVertex2f(385, 60);

    glVertex2f(385, 120);

    glVertex2f(380, 120);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(370, 125);

    glVertex2f(365, 120);

    glVertex2f(400, 120);

    glVertex2f(395, 125);

    glEnd();



        glBegin(GL_POLYGON);
  float x6 = 383;
  float y6= 135;
  for (int i = 0; i < 300; i++)
  {
        glColor3ub(255, 255, 255);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 10.25;
       float x = r * cos(a) + x6;
       float y = r * sin(a) + y6;
       glVertex2f(x, y);
  }
  glEnd();




   glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(450, 60);

    glVertex2f(455, 60);

    glVertex2f(455, 120);

    glVertex2f(450, 120);

    glEnd();



    glColor3ub(2, 48, 32);

    glBegin(GL_POLYGON);

    glVertex2f(440, 125);

    glVertex2f(435, 120);

    glVertex2f(470, 120);

    glVertex2f(465, 125);

    glEnd();



            glBegin(GL_POLYGON);
  float x7 = 453;
  float y7= 135;
  for (int i = 0; i < 300; i++)
  {
       glColor3ub(255, 255, 255);
       float pi = 3.1416;
       float a = (i * 2 * pi) / 300;
       float r = 10.25;
       float x = r * cos(a) + x7;
       float y = r * sin(a) + y7;
       glVertex2f(x, y);
  }
  glEnd();

  glColor3ub(1, 1, 1);

    glBegin(GL_POLYGON);

    glVertex2f(470, 180);

    glVertex2f(475, 180);

    glVertex2f(475, 280);

    glVertex2f(470, 280);

    glEnd();

     glColor3ub(26, 35, 126);

    glBegin(GL_POLYGON);

    glVertex2f(465, 290);

    glVertex2f(456, 280);

    glVertex2f(490, 280);

    glVertex2f(482, 290);

    glEnd();

    glColor3ub(255, 255, 255);

    glBegin(GL_POLYGON);

    glVertex2f(465, 305);

    glVertex2f(465, 290);

    glVertex2f(482, 290);

    glVertex2f(482, 305);

    glEnd();

     glColor3ub( 183, 28, 28);

    glBegin(GL_POLYGON);

    glVertex2f(473, 314);

    glVertex2f(465, 305);

    glVertex2f(482, 305);

    glEnd();

}

void display(void)
{

    glClear(GL_COLOR_BUFFER_BIT);

    //Sky Color

    glColor3ub(30, 144, 255);
    glBegin(GL_POLYGON);
    glVertex2f(0, 0);
    glVertex2f(500, 0);
    glVertex2f(500, 500);
    glVertex2f(0, 500);
    glEnd();

    Bushes();

    //Ground Color
    glColor3ub(50, 205, 50);
    glBegin(GL_POLYGON);
    glVertex2f(0, 0);
    glVertex2f(500, 0);
    glVertex2f(500, 180);
    glVertex2f(0, 180);
    glEnd();

road();
sun();
clouds();
tree();
little_tree();
road1();
car();
buil1();
buil2();
buil3();
buil4();
building_car();
truck();

    glFlush();
    glutSwapBuffers();

}



int main(int argc, char** argv)

{

    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);

    glutInitWindowSize(900, 500);

    glutInitWindowPosition(100, 100);

    glutCreateWindow("CityView");

    init();

    glutDisplayFunc(display);

    glutMainLoop();

    return 0;

}

